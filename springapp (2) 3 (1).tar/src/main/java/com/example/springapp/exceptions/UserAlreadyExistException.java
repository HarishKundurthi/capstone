package com.example.springapp.exceptions;

public class UserAlreadyExistException extends RuntimeException{

    public String toString(){
        return "UserAlreadyExistException : User already exist";
    }
}
