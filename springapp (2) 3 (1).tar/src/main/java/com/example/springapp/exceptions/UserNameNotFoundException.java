package com.example.springapp.exceptions;

public class UserNameNotFoundException extends RuntimeException{

    public String toString(){
        return "UserNameNotFoundException : User Name Not Found";
    }
    
}
