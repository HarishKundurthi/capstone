package com.example.springapp.exceptions;

public class CourseNotFoundException extends RuntimeException {
    
    public String toString(){
        return "CourseNotFoundException : Course Not Found";
    }
    
}
