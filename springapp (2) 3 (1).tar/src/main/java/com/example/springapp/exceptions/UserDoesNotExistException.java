package com.example.springapp.exceptions;

public class UserDoesNotExistException extends RuntimeException{

    public String toString(){
        return "UserDoesNotExistException : Username invalid";
    }
}