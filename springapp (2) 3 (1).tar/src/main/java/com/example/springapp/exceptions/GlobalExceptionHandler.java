package com.example.springapp.exceptions;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(UserAlreadyExistException.class)
    public ResponseEntity<String> userAlreadExistHandler(UserAlreadyExistException userAlreadyExistException){
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(userAlreadyExistException.toString());
    }

    @ExceptionHandler(InvalidCredentialsException.class)
    public ResponseEntity<String> invalidCredentialsHandler(InvalidCredentialsException invalidCredentialsException){
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(invalidCredentialsException.toString());
    }

    @ExceptionHandler(UserDoesNotExistException.class)
    public ResponseEntity<String> userDoesNotExistHandler(UserDoesNotExistException userDoesNotExistException){
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(userDoesNotExistException.toString());
    }

    @ExceptionHandler(CourseNotFoundException.class)
    public ResponseEntity<String> courseNotFoundException(CourseNotFoundException courseNotFoundException){
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(courseNotFoundException.toString());
    }

    @ExceptionHandler(EnquiryNotFoundException.class)
    public ResponseEntity<String> enquiryNotFoundException(EnquiryNotFoundException enquiryNotFoundException){
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(enquiryNotFoundException.toString());
    }

    @ExceptionHandler(StudentNotFoundException.class)
    public ResponseEntity<String> studentNotFoundException(StudentNotFoundException studentNotFoundException){
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(studentNotFoundException.toString());
    }

    @ExceptionHandler(PaymentNotFoundException.class)
    public ResponseEntity<String> paymentNotFoundException(PaymentNotFoundException paymentNotFoundException){
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(paymentNotFoundException.toString());
    }

    @ExceptionHandler(UserNameNotFoundException.class)
    public ResponseEntity<String> userNameNotFoundException(UserNameNotFoundException userNameNotFoundException){
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(userNameNotFoundException.toString());
    }

    @ExceptionHandler
    public ResponseEntity<String> noEnquiriesFoundException(NoEnquiriesFoundException noEnquiriesFoundException){
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(noEnquiriesFoundException.toString());
    }
}

