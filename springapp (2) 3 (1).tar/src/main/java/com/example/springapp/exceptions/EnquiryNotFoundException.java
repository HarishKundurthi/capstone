package com.example.springapp.exceptions;

public class EnquiryNotFoundException extends RuntimeException{

    public String toString(){
        return "EnquiryNotFoundException : Enquiry not Found";
    }
    
}
