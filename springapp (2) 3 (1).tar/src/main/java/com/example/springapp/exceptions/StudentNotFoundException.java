package com.example.springapp.exceptions;

public class StudentNotFoundException extends RuntimeException{

    public String toString(){
        return "StudentNotFoundException : Student Not Found";
    }
    
}
