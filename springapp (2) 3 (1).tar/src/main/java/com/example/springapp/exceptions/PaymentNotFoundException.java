package com.example.springapp.exceptions;

public class PaymentNotFoundException extends RuntimeException{

    public String toString(){
        return "PaymentNotFoundException : Payment Not Found";
    }
    
}
