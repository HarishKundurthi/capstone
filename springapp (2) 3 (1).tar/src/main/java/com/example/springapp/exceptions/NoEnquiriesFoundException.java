package com.example.springapp.exceptions;

public class NoEnquiriesFoundException extends RuntimeException{
    public String toString(){
        return "NoEnquiriesFoundException : No Enquiries Found";
    }
    
}
