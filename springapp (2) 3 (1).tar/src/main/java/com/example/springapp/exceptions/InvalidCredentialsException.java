package com.example.springapp.exceptions;

public class InvalidCredentialsException extends RuntimeException{

    public String toString(){
        return "InvalidCredentialsException : Invalid credentials";
    }
}

