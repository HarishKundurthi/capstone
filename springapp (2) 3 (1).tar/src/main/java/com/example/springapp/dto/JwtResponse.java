package com.example.springapp.dto;


// import lombok.AllArgsConstructor;
// import lombok.Data;
// import lombok.NoArgsConstructor;

// @NoArgsConstructor
// @AllArgsConstructor
// @Data
public class JwtResponse {
    private String token;
    private Long userId;
    private String userName;
    private String role;
    
    public JwtResponse() {
    }

    public JwtResponse(String token, Long userId, String userName, String role) {
        this.token = token;
        this.userId = userId;
        this.userName = userName;
        this.role = role;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long long1) {
        this.userId = long1;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    
    
}

