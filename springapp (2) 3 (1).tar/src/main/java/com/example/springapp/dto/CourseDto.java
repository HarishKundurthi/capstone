package com.example.springapp.dto;

public class CourseDto {
    private Long courseID;
    private String courseName; 
    private String description; 
    private String duration; 
    private Long cost;



    
    public CourseDto(Long courseID, String courseName, String description, String duration, Long cost) {
        this.courseID = courseID;
        this.courseName = courseName;
        this.description = description;
        this.duration = duration;
        this.cost = cost;
    }
    
    public Long getCourseID() {
        return courseID;
    }
    public void setCourseID(Long courseID) {
        this.courseID = courseID;
    }
    public String getCourseName() {
        return courseName;
    }
    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }
    public String getDescription() {
        return description;
    }
    public void setDescription(String description) {
        this.description = description;
    }
    public String getDuration() {
        return duration;
    }
    public void setDuration(String duration) {
        this.duration = duration;
    }
    public Long getCost() {
        return cost;
    }
    public void setCost(Long cost) {
        this.cost = cost;
    }
}
