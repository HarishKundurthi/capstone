package com.example.springapp.repositories;

import java.util.Optional;

import com.example.springapp.model.Student;
import com.example.springapp.model.User;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
@Repository
public interface UserRepository extends JpaRepository<User,Long>{

    public Optional<User> findByUsername(String username);
    User findByUserRole(String userRole);
    public Optional<User> findByEmail(String email);
}
