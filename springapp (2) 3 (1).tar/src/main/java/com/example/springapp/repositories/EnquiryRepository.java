package com.example.springapp.repositories;

import java.util.List;

import com.example.springapp.model.Enquiry;
import com.example.springapp.model.Student;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
@Repository
public interface EnquiryRepository extends JpaRepository<Enquiry,Long>{
    
    List<Enquiry> findByStudent(Student student);
	Enquiry getEnquiryByStudentAndEnquiryId(Student student, Long enquiryId);
}
