package com.example.springapp.controllers;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;



import javax.annotation.security.RolesAllowed;

import com.example.springapp.dto.ResponseData;

@RestController
@CrossOrigin()
public class RestApiController {

    @GetMapping("/api/admin")
    @RolesAllowed({"ADMIN"})
    public ResponseEntity<ResponseData> getAdmin(){
        return ResponseEntity.status(HttpStatus.OK).body(new ResponseData("Hello world from admin"));
    }

    @GetMapping("/api/user")
    @RolesAllowed("USER")
    public ResponseEntity<ResponseData> getUser(){
        return ResponseEntity.status(HttpStatus.OK).body(new ResponseData("Hello world from User"));
    }

    @GetMapping("/api/guest")
    public ResponseEntity<ResponseData> getGuest(){
        return  ResponseEntity.status(HttpStatus.OK).body(new ResponseData("Hello world from Guest"));
    }


}
