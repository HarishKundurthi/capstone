package com.example.springapp.controllers;

import java.util.List;

import com.example.springapp.ApiServices.CourseServiceImpl;
import com.example.springapp.dto.CourseDto;
import com.example.springapp.model.Course;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin()
public class CourseController {


    @Autowired CourseServiceImpl courseService;
    
    @GetMapping("/api/course")
    public ResponseEntity<List<Course>> getAllCourses(){
        System.out.println("testing all courses");
        return ResponseEntity.status(HttpStatus.OK).body(courseService.getAllCourses());
    }

    @GetMapping("/api/course/{courseId}")
    public ResponseEntity<Course> getCourseById(@PathVariable Long courseId){
        return ResponseEntity.status(HttpStatus.OK).body(courseService.getCourseById(courseId));
    }

    @PostMapping("/api/course")
    public ResponseEntity<Course> saveCourseByAdmin(@RequestBody CourseDto course){
        System.out.println("course:"+course);
        return ResponseEntity.status(HttpStatus.OK).body(courseService.createCourse(course));
    }

    @PutMapping("/api/course/{courseId}")
    public ResponseEntity<Course> updateCourseByAdmin(@PathVariable Long courseId,@RequestBody CourseDto course){
        return ResponseEntity.status(HttpStatus.OK).body(courseService.editCourse(courseId,course));
    }

    @DeleteMapping("/api/course/{courseId}")
    public ResponseEntity<Course> deleteCourseByAdmin(@PathVariable Long courseId){
        return ResponseEntity.status(HttpStatus.OK).body(courseService.deleteCourse(courseId));
    }

    @GetMapping("/api/student/course")
    public ResponseEntity<List<Course>> getStudentCourses(){
        System.out.println("testing all courses");
        return ResponseEntity.status(HttpStatus.OK).body(courseService.getAllCourses());
    }

    }