package com.example.springapp.controllers;


import com.example.springapp.ApiServices.AuthService;
import com.example.springapp.dto.Dto;
import com.example.springapp.dto.JwtRequest;
import com.example.springapp.dto.JwtResponse;
import com.example.springapp.model.Student;
import com.example.springapp.model.User;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@CrossOrigin 
public class AuthController {

    @Autowired
    private AuthService authService;


    @PostMapping("/auth/register")
    public ResponseEntity<Boolean> registerUser(@RequestBody Dto dto){
        authService.registerUser(dto);
        return ResponseEntity.status(HttpStatus.OK).body(true);
    }

    @PostMapping("/auth/login")
    public ResponseEntity<JwtResponse> login(@RequestBody JwtRequest jwtRequest){
        JwtResponse token = authService.login(jwtRequest);
        System.out.println("Generated token : "+token);
        return ResponseEntity.status(HttpStatus.OK).body(token);

    }

}
