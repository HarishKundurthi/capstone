package com.example.springapp.controllers;

import java.util.Set;
import com.example.springapp.ApiServices.PaymentServiceImpl;
import com.example.springapp.model.Payment;
import java.net.ResponseCache;
import java.util.List;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin()
public class PaymentController{

    @Autowired PaymentServiceImpl paymentService;

    @GetMapping("/api/payment")
    public ResponseEntity<List<Payment>> getAllPayments(){
        return ResponseEntity.status(HttpStatus.OK).body(paymentService.getAllPayments());
    }

    @PostMapping("/api/payment")
    public ResponseEntity<Payment> createPayment(@RequestBody Payment payment){
        return ResponseEntity.status(HttpStatus.OK).body(paymentService.makePayment(payment));
    }

    @GetMapping("/api/payment/{studentId}")
    public ResponseEntity<List<Payment>> getPaymentByStudentId(@PathVariable Long studentId){
        return ResponseEntity.status(HttpStatus.OK).body(paymentService.getPaymentByStudentId(studentId));
    }

    @PostMapping("/api/payment/{studentId}")
    public ResponseEntity<Payment> makePaymentById(@PathVariable Long studentId, @RequestBody Payment payment){
        return ResponseEntity.status(HttpStatus.OK).body(paymentService.makePaymentById(studentId,payment));
    }

    
}
