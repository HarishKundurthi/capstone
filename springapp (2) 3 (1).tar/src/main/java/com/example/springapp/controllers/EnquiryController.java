package com.example.springapp.controllers;

import java.util.List;

import com.example.springapp.ApiServices.EnquiryServiceImpl;
import com.example.springapp.model.Enquiry;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin()
public class EnquiryController {
    
 
    @Autowired EnquiryServiceImpl enquiryService;

    @GetMapping("/api/enquiry")
    public ResponseEntity<List<Enquiry>> getAllEnquiries(){
        return ResponseEntity.status(HttpStatus.OK).body(enquiryService.getAllEnquiries());
    }

    @PostMapping("/api/enquiry")
    public ResponseEntity<Enquiry> createEnquiry(@RequestBody Enquiry enquiry){
        return ResponseEntity.status(HttpStatus.OK).body(enquiryService.createEnquiry(enquiry));
    }
    

    @GetMapping("/api/enquiry/{enquiryId}")
    public ResponseEntity<Enquiry> getEnquiryById(@PathVariable Long enquiryId){
        return ResponseEntity.status(HttpStatus.OK).body(enquiryService.getEnquiryById(enquiryId));
    }

    @GetMapping("/api/user/{userId}")
    public ResponseEntity<List<Enquiry>> getEnquiryByUserId(@PathVariable Long userId){
        return ResponseEntity.status(HttpStatus.OK).body(enquiryService.getEnquirybyUserId(userId));
    }

    @GetMapping("/api/user/{userId}/enquiry/{enquiryId}")
    public ResponseEntity<Enquiry> getEnquiryByUserIdAndEnquiryId(@PathVariable Long userId,@PathVariable Long enquiryId){
        return ResponseEntity.status(HttpStatus.OK).body(enquiryService.getEnquiryByUserIdAndEnquiryId(userId,enquiryId));
    }


    //for creating Enquiry from Front End
    @PostMapping("/api/user/{userId}/enquiry")
    public ResponseEntity<Enquiry> createEnquiryByUserId(@PathVariable Long userId,@RequestBody Enquiry enquiry){

        return ResponseEntity.status(HttpStatus.OK).body(enquiryService.createEnquiryByUserId(userId,enquiry));
    }

   

    @PutMapping("/api/user/{userId}/enquiry/{enquiryId}")
    public ResponseEntity<Enquiry> editEnquiry(@PathVariable Long userId,@PathVariable Long enquiryId,@RequestBody Enquiry enquiry){
        System.out.println("input_enquiry:"+enquiry);
        return ResponseEntity.status(HttpStatus.OK).body(enquiryService.editEnquiry(userId,enquiryId,enquiry));
    }

    @DeleteMapping("/api/user/{userId}/enquiry/{enquiryId}")
    public ResponseEntity<Enquiry> deleteEnquiry(@PathVariable Long userId,@PathVariable Long enquiryId){
        return ResponseEntity.status(HttpStatus.OK).body(enquiryService.deleteEnquiryByUserIdAndEnquiryId(userId,enquiryId));
    }

    @DeleteMapping("api/enquiry/{enquiryId}")
    public ResponseEntity<Enquiry> deleteEnquiry(@PathVariable Long enquiryId){
        return ResponseEntity.status(HttpStatus.OK).body(enquiryService.deleteEnquiry(enquiryId));
    }
}
