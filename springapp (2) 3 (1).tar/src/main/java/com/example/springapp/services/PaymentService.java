package com.example.springapp.services;

import java.util.List;

import com.example.springapp.model.Payment;

public interface PaymentService {
    // public List<Payment> getAllPayments();
    // public Payment getPaymentById(Long paymentId);
    // public Payment makePayment(Payment payment);
    // public List<Payment> getPaymentByStudentId(Long studentId);
    // public Payment makePaymentById(Long studentId,Payment payment);

 //Displaying all Payments
 
    public List<Payment> getAllPayments();
 
    //Displaying payment By ID
 
    public Payment getPaymentById(Long paymentId);
 
    //Making Payment
 
    public Payment makePayment(Payment payment);
 
    //Displaying List of Payments done by Student
 
    public List<Payment> getPaymentByStudentId(Long studentId);
 
    //Making Payment By StudentID
   
    public Payment makePaymentById(Long studentId,Payment payment);
}
