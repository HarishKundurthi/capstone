package com.example.springapp.services;

import com.example.springapp.model.User;

public interface UserService {
    // public User addUser(User user);

     //Performing Admin Registration
   
     public User addUser(User user);
}
