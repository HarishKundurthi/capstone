package com.example.springapp.services;

import java.util.List;

import com.example.springapp.model.Student;

public interface StudentService {
    // public Student getStudentById(Long studentId);
    // public List<Student> getAllStudents();

    //Getting a Student with Student ID
 
    public Student getStudentById(Long studentId);
 
    //Admin Viewing all the Students
   
    public List<Student> getAllStudents();
}
