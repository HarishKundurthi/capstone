package com.example.springapp.services;

import java.util.List;

import com.example.springapp.model.Course;

public interface CourseService {
    // public List<Course> getAllCourses();
    // public Course getCourseById(Long courseId);
    // public Course createCourse(Course course);
    // public Course editCourse(Long courseId,Course course);
    // public Course deleteCourse(Long courseId);

 
    //Viewing All the Courses
 
    public List<Course> getAllCourses();
 
    //Fetching Course By ID
 
    public Course getCourseById(Long courseId);
 
    //Admin Creating a Course
 
    public Course createCourse(Course course);
 
    //Admin editing a Course
 
    public Course editCourse(Long courseId,Course course);
 
    //Admin Deleting a course
   
    public Course deleteCourse(Long courseId);
}
