package com.example.springapp.services;

import java.util.List;

import com.example.springapp.model.Enquiry;



public interface EnquiryService {
    // public List<Enquiry> getAllEnquiries();
    // public Enquiry getEnquiryById(Long enquiryId);
    // public List<Enquiry> getEnquirybyUserId(Long userId);
    // public Enquiry createEnquiry(Enquiry enquiry);
    // public Enquiry createEnquiryByEnquiryId(Long enquiryId,Enquiry enquiry);
    // public Enquiry createEnquiryByUserId(Long userId,Enquiry enquiry);
    // public Enquiry deleteEnquiry(Long enquiryId);
    // public Enquiry getEnquiryByUserIdAndEnquiryId(Long userId, Long enquiryId);

    
//Displaying All The Enquiries
 
    public List<Enquiry> getAllEnquiries();
 
    //Displaying Enquiry By ID
 
    public Enquiry getEnquiryById(Long enquiryId);
 
    //Displaying Enquiries By User ID
 
    public List<Enquiry> getEnquirybyUserId(Long userId);
 
    //Creating an Enquiry
 
    public Enquiry createEnquiry(Enquiry enquiry);
 
    //Editing Enquiry By Enquiry ID
 
    public Enquiry createEnquiryByEnquiryId(Long enquiryId,Enquiry enquiry);
 
    //Creating Enquiry By User ID
 
    public Enquiry createEnquiryByUserId(Long userId,Enquiry enquiry);
 
    //Deleting Enquiry By Enquiry ID
 
    public Enquiry deleteEnquiry(Long enquiryId);
 
    //Displaying Enquiry By User ID and Enquiry ID
 
    public Enquiry getEnquiryByUserIdAndEnquiryId(Long userId, Long enquiryId);
 
    //Editing an Enquiry
 
    public Enquiry editEnquiry(Long userId,Long enquiryId,Enquiry enquiry);
 
    //Deleting an Enquiry
   
    public Enquiry deleteEnquiryByUserIdAndEnquiryId(Long userId,Long enquiryId);
}
