package com.example.springapp.config;




import java.util.Arrays;

import com.example.springapp.util.JwtFilter;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfiguration;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
import org.springframework.web.servlet.config.annotation.CorsRegistry;

@Configuration
@EnableWebSecurity
@EnableGlobalMethodSecurity(
        securedEnabled = true,
        jsr250Enabled = true,
        prePostEnabled = true
)
public class SecurityConfiguration extends WebSecurityConfigurerAdapter {

    @Autowired
    private UserDetailsService userDetailsService;

    @Autowired
    private JwtFilter jwtFilter;

    @Override
    public void configure(AuthenticationManagerBuilder authenticationManager)throws Exception{
        authenticationManager.userDetailsService(userDetailsService);
    }

   
    @Override
    protected void configure(HttpSecurity http) throws Exception {
       
        http.csrf().disable().cors().and()
                .sessionManagement()
                .sessionCreationPolicy(SessionCreationPolicy.STATELESS)
                .and()
                .authorizeRequests()
                .antMatchers("/auth/register","/auth/login","/api/guest","/api/student")
                .permitAll()
                .antMatchers("/api/admin","/api/user","/api/enquiry","/api/user/{userId}","/api/course","/api/payment/{studentId}","/api/user/{userId}/enquiry/{enquiryId}","/api/course/{courseId}")
                .authenticated()
                .antMatchers(HttpMethod.GET,"/api/enquiry","/api/payment")
                .hasRole("ADMIN")
                .antMatchers(HttpMethod.POST,"/api/enquiry","/api/payment","/api/user/{userId}/enquiry")
                .hasRole("STUDENT")
                .anyRequest()
                .authenticated();
                

        // Apply JWT filter
        http.addFilterBefore(jwtFilter, UsernamePasswordAuthenticationFilter.class);
    }

    @Bean
	public CorsConfigurationSource corsConfigurationSource() {
	    CorsConfiguration configuration = new CorsConfiguration();
	    configuration.setAllowedOrigins(Arrays.asList("https://8081-bacaadcecacbdaaacbebeceaaeabdabae.premiumproject.examly.io","http://localhost:9876","https://8081-aefaacacebcdfbdbbecacfefdfdabaabbcb.premiumproject.examly.io","https://us-central1-naga-test-350508.cloudfunctions.net/dialogflow-test")); // Allow your frontend's origin
	    configuration.setAllowedMethods(Arrays.asList("GET", "POST", "PUT", "DELETE"));
	    configuration.setAllowedHeaders(Arrays.asList("*"));
	    configuration.setAllowCredentials(true);

	    UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
	    source.registerCorsConfiguration("/**", configuration);
	    return source;
    }
}


