package com.example.springapp.config;

import com.example.springapp.ApiServices.AuthService;
import com.example.springapp.model.User;

// import com.ssce.springsecurityapi.model.User;
// import com.ssce.springsecurityapi.repository.UserRepository;
// import com.ssce.springsecurityapi.service.AuthService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Component;

@Component
public class UserDetailsServiceImpl implements UserDetailsService {

    @Autowired
    private AuthService authService;

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        User user = authService.getUserByUsername(username);
        if(user == null){
            new UsernameNotFoundException("Invalid Credentials");
        }
        UserDetails userDetails =  new UserDetailsImpl(user.getUsername(),user.getPassword(),user.getUserRole());
        return userDetails;
    }
}
