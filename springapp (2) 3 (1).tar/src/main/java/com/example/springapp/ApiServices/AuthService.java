package com.example.springapp.ApiServices;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCrypt;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Optional;

import com.example.springapp.dto.Dto;
import com.example.springapp.dto.JwtRequest;
import com.example.springapp.dto.JwtResponse;
import com.example.springapp.exceptions.InvalidCredentialsException;
import com.example.springapp.exceptions.UserAlreadyExistException;
import com.example.springapp.exceptions.UserNameNotFoundException;
import com.example.springapp.model.Student;
import com.example.springapp.model.User;
import com.example.springapp.repositories.StudentRepository;
import com.example.springapp.repositories.UserRepository;
import com.example.springapp.util.JwtUtility;

@Service
public class AuthService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private StudentRepository studentRepository;

    @Autowired
    private JwtUtility jwtUtility;

    //Encodes password using BCrypt password encoder
    public String passwordEncoder(String password){
        return new BCryptPasswordEncoder().encode(password);
    }

    //Fetches userByName
    public User getUserByUsername(String username){
        Optional<User> optUser = userRepository.findByUsername(username);
        if(optUser.isPresent()){
            return optUser.get();
        }else
            throw new UserNameNotFoundException();
    }

    // -------User and admin registration----
    public User registerUser(Dto dto){
        System.out.println("Register User started......................"+dto.getUsername());
        User existingUser = userRepository.findByUsername(dto.getUsername()).orElse(null);
        System.out.println("Existing user "+existingUser);
        if(null==existingUser){
            User user = new User();
            System.out.println("Password : "+passwordEncoder((dto.getPassword())));
            user.setPassword(passwordEncoder(dto.getPassword()));
            user.setUsername(dto.getUsername());
            user.setEmail(dto.getEmail());
            

            if(dto.getUserRole().equals("ADMIN"))
            {
               user.setUserRole("ROLE_ADMIN");
               userRepository.save(user);
               
            }
            else if(dto.getUserRole().equals("STUDENT"))
            {
                user.setUserRole("ROLE_STUDENT");
                userRepository.save(user);
                Student student = new Student();
                student.setStudentName(user.getUsername());
                student.setStudentEmail(user.getEmail());
                student.setStudentMobileNumber(dto.getmobileNumber());
                student.setUser(user);
                student = studentRepository.save(student);
            }
            return user;
            
        }else {
            return null;
            //throw new UserAlreadyExistException();
        }
    }

    
    //JWT LOGIN
    public JwtResponse login(JwtRequest jwtRequest){
        //User user = userRepository.findByUsername(jwtRequest.getUsername()).orElse(null);
        User user = userRepository.findByEmail(jwtRequest.getEmail()).orElse(null);

        if(user == null) {
            throw new InvalidCredentialsException();
        }

        if((new BCryptPasswordEncoder()).matches(jwtRequest.getPassword(),user.getPassword())){
            System.out.println("Valid password");
            JwtResponse response = new JwtResponse();
            JwtRequest ModifiedjwtRequest = new JwtRequest();
            jwtRequest.setUsername(user.getUsername());
            //ModifiedjwtRequest.setUsername(user.getUsername());
            //ModifiedjwtRequest.setUsername(jwtRequest.getPassword());
            response.setToken(jwtUtility.generateToken(jwtRequest));
            response.setUserName(user.getUsername());
            response.setRole(user.getUserRole());

            //System.out.println(user.getUserRole());
            if((user.getUserRole()).equals("ROLE_STUDENT"))
            {
                //Student student = studentRepository.findByStudentName(jwtRequest.getUsername()).orElse(null);
                Student student = studentRepository.findByStudentEmail(jwtRequest.getEmail()).orElse(null);
                response.setUserId(student.getStudentId());
                System.out.println(jwtRequest.getUsername()+"if"+student);
            }
            else
            {
                response.setUserId(user.getUserId());
                System.out.println("Admin");
            }

            return response;
        }else{
            throw new InvalidCredentialsException();
        }

    }




}
