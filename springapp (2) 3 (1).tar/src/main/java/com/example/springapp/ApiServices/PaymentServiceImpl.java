package com.example.springapp.ApiServices;


import java.util.List;

import com.example.springapp.exceptions.PaymentNotFoundException;
import com.example.springapp.model.Course;
import com.example.springapp.model.Payment;
import com.example.springapp.model.Student;
import com.example.springapp.repositories.CourseRepository;
import com.example.springapp.repositories.PaymentRepository;
import com.example.springapp.repositories.StudentRepository;
import com.example.springapp.services.PaymentService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class PaymentServiceImpl implements PaymentService{
    @Autowired private PaymentRepository paymentRepository;
    @Autowired private StudentRepository studentRepository;
    @Autowired private CourseRepository courseRepository;

    //Displaying all Payments
    public List<Payment> getAllPayments(){
        return paymentRepository.findAll();
    }

    //Displaying payment By ID
    public Payment getPaymentById(Long paymentId){
        return paymentRepository.findById(paymentId).orElse(null); 
    }

    //Making Payment
    public Payment makePayment(Payment payment){
        Long Student_id=payment.getStudentId();
        Student student=studentRepository.findById(Student_id).orElse(null);
        Long course_id=payment.getCourseId();
        Course course=courseRepository.findById(course_id).orElse(null);
        course.getStudents().add(student);
        course.getPayment().add(payment);
        payment.setCourse(course);
        student.getCourses().add(course);
        paymentRepository.save(payment);
        courseRepository.save(course);
        studentRepository.save(student);
        return payment;
    }

    //Displaying List of Payments done by Student
    public List<Payment> getPaymentByStudentId(Long studentId) {
        return paymentRepository.findBystudentId(studentId);
    }

    //Making Payment By StudentID
    public Payment makePaymentById(Long studentId,Payment payment){
        Student student=studentRepository.findById(studentId).orElse(null);
        if(null==student){
            throw new PaymentNotFoundException();
        }
        Long course_id=payment.getCourseId();
        Course course=courseRepository.findById(course_id).orElse(null);
        course.getStudents().add(student);
        course.getPayment().add(payment);
        payment.setCourse(course);
        student.getCourses().add(course);
        paymentRepository.save(payment);
        courseRepository.save(course);
        studentRepository.save(student);
        return payment;
    }

}