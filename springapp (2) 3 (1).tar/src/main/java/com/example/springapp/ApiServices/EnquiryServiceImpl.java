package com.example.springapp.ApiServices;

import java.util.List;

import com.example.springapp.exceptions.EnquiryNotFoundException;
import com.example.springapp.exceptions.StudentNotFoundException;
import com.example.springapp.model.Course;
import com.example.springapp.model.Enquiry;
import com.example.springapp.model.Student;
import com.example.springapp.repositories.CourseRepository;
import com.example.springapp.repositories.EnquiryRepository;
import com.example.springapp.repositories.StudentRepository;
import com.example.springapp.repositories.UserRepository;
import com.example.springapp.services.EnquiryService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class EnquiryServiceImpl implements EnquiryService{

    @Autowired private EnquiryRepository enquiryRepository;
    @Autowired private UserRepository userRepository;
    @Autowired private StudentRepository studentRepository;
    @Autowired private CourseRepository courseRepository;

    //Displaying All The Enquiries
    public List<Enquiry> getAllEnquiries(){
        return enquiryRepository.findAll();
    }

    //Displaying Enquiry By ID
    public Enquiry getEnquiryById(Long enquiryId){
        Enquiry tempenquiry=enquiryRepository.findById(enquiryId).orElse(null);
        if(null==tempenquiry){
            throw new EnquiryNotFoundException();
        }
        else{
            return tempenquiry;
        }
    }

    //Displaying Enquiries By User ID
    public List<Enquiry> getEnquirybyUserId(Long userId){
        Student student=studentRepository.findById(userId).orElse(null);
        return enquiryRepository.findByStudent(student);
    }

    //Creating an Enquiry
    public Enquiry createEnquiry(Enquiry enquiry){
        return enquiryRepository.save(enquiry);
    }

    //Editing Enquiry By Enquiry ID
    public Enquiry createEnquiryByEnquiryId(Long enquiryId,Enquiry enquiry){
        Enquiry tempenquiry=enquiryRepository.findById(enquiryId).orElse(null);
        if(null==tempenquiry){
            throw new EnquiryNotFoundException();
        }
        else{
            enquiryRepository.save(enquiry);
            return enquiry;
        }
    }

        //Creating Enquiry By User ID
        public Enquiry createEnquiryByUserId(Long userId,Enquiry enquiry) {
        	Student student=studentRepository.findById(userId).orElse(null);
            Course input_course=enquiry.getCourse();
            Long course_id=input_course.getCourseId();
            Course course=courseRepository.findById(course_id).orElse(null);
            //System.out.println("Student:"+student);
            if(null==student){
                throw new StudentNotFoundException();
            }
            //System.out.println("course:"+course);

            enquiry.setStudent(student);
            enquiry.setCourse(course);
            student.getEnquiry().add(enquiry);
            course.getEnquiries().add(enquiry);

            enquiryRepository.save(enquiry);
            studentRepository.save(student);
            courseRepository.save(course);
            
            return enquiry; 
        }

    //Deleting Enquiry By ENquiry ID
    public Enquiry deleteEnquiry(Long enquiryId){
        Enquiry tempenquiry=enquiryRepository.findById(enquiryId).orElse(null);
        if(null==tempenquiry){
            throw new EnquiryNotFoundException();
        }
        else{
            Student student = tempenquiry.getStudent();
            Course course = tempenquiry.getCourse();
            tempenquiry.setStudent(null);
            tempenquiry.setCourse(null);
            student.getEnquiry().remove(tempenquiry);
            course.getEnquiries().remove(tempenquiry);
            enquiryRepository.delete(tempenquiry);
            studentRepository.save(student);
            courseRepository.save(course);
            return tempenquiry;
        }
    }

    //Displaying Enquiry By User ID and Enquiry ID
	public Enquiry getEnquiryByUserIdAndEnquiryId(Long userId, Long enquiryId) {
        Student student=studentRepository.findById(userId).orElse(null);
		return enquiryRepository.getEnquiryByStudentAndEnquiryId(student,enquiryId);
	}

    public Enquiry editEnquiry(Long userId,Long enquiryId,Enquiry enquiry){
        
        //Student student=studentRepository.findById(userId).orElse(null);
        Enquiry tempenquiry=enquiryRepository.findById(enquiryId).orElse(null);
        if(null==enquiry || null==tempenquiry){
            throw new EnquiryNotFoundException();
        }
        Student student = tempenquiry.getStudent();
        Course course=tempenquiry.getCourse();
        enquiry.setStudent(student);
        enquiry.setCourse(course);
        enquiryRepository.save(enquiry);
        return enquiry;
    }

    public Enquiry deleteEnquiryByUserIdAndEnquiryId(Long userId,Long enquiryId){
        //Student student=studentRepository.findById(userId).orElse(null);
        Enquiry enquiry=enquiryRepository.findById(enquiryId).orElse(null);
        if(null==enquiry){
           throw new EnquiryNotFoundException();
        }

        Student student = enquiry.getStudent();
        Course course = enquiry.getCourse();
        enquiry.setStudent(null);
        enquiry.setCourse(null);
        student.getEnquiry().remove(enquiry);
        course.getEnquiries().remove(enquiry);
        enquiryRepository.delete(enquiry);
        courseRepository.save(course);
        studentRepository.save(student);

        enquiryRepository.delete(enquiry);
        return enquiry;
    }
}