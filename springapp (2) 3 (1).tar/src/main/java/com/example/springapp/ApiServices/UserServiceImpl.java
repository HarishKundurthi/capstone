package com.example.springapp.ApiServices;

import com.example.springapp.model.User;
import com.example.springapp.repositories.UserRepository;
import com.example.springapp.services.UserService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
@Service
public class UserServiceImpl implements UserService {
    
    @Autowired
    private UserRepository userRepository;

    //Performing Admin Registration 
    public User addUser(User user) {
        user.setUserRole("ROLE_ADMIN");
        return userRepository.save(user);
    }
        
}
