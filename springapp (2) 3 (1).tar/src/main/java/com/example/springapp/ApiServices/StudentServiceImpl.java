package com.example.springapp.ApiServices;

import java.util.List;

import com.example.springapp.dto.Dto;
import com.example.springapp.exceptions.StudentNotFoundException;
import com.example.springapp.model.Student;
import com.example.springapp.model.User;
import com.example.springapp.repositories.StudentRepository;
import com.example.springapp.repositories.UserRepository;
import com.example.springapp.services.StudentService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class StudentServiceImpl implements StudentService {

    @Autowired
    private UserRepository userRepository;
    
    @Autowired
    private StudentRepository studentRepository;

    //Admin can retrieve all students 
    public List<Student> getAllStudents(){
        return studentRepository.findAll();
    }

    //Admin can get students using studentId
    public Student getStudentById(Long studentId) {
        Student student=studentRepository.findById(studentId).orElse(null);
        if(null==student){
            throw new StudentNotFoundException();
        }
        else{
            return student;
        }
    }
    
}
