package com.example.springapp.ApiServices;
import java.util.List;

import com.example.springapp.dto.CourseDto;
import com.example.springapp.exceptions.CourseNotFoundException;
import com.example.springapp.model.Course;
import com.example.springapp.repositories.CourseRepository;
import com.example.springapp.services.CourseService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CourseServiceImpl implements CourseService{
    
    @Autowired 
    private CourseRepository courseRepository;
    
    @Autowired 
    private EnquiryServiceImpl enquiryService;

    //get all courses
    public List<Course> getAllCourses(){
        System.out.println("testing all courses");
        return courseRepository.findAll();
    }

    //get the course using courseid
    public Course getCourseById(Long courseId){
        Course course=courseRepository.findById(courseId).orElse(null);
        if(null==course){
            throw new CourseNotFoundException();
        }
        else{
            return course;
        }
    }

    //admin creates a course
    public Course createCourse(CourseDto course){
        Course newCourse = new Course();
        newCourse.setCourseId(course.getCourseID());
        newCourse.setCourseName(course.getCourseName());
        newCourse.setDescription(course.getDescription());
        newCourse.setCost(course.getCost());
        newCourse.setDuration(course.getDuration());
        return courseRepository.save(newCourse);
    }

    //admin editing a course
    public Course editCourse(Long courseId,CourseDto course){
        Course tempcourse=courseRepository.findById(courseId).orElse(null);
        Course editCourse = new Course();
        if(null==tempcourse){
            throw new CourseNotFoundException();
        }
        editCourse.setCourseId(course.getCourseID());
        editCourse.setCourseName(course.getCourseName());
        editCourse.setDescription(course.getDescription());
        editCourse.setCost(course.getCost());
        editCourse.setDuration(course.getDuration());
        editCourse.getStudents().addAll(tempcourse.getStudents());
        editCourse.setPayment(tempcourse.getPayment());
        System.out.println(editCourse);
        return courseRepository.save(editCourse);
    }

    //admin deleting a course
    public Course deleteCourse(Long courseId){
        System.out.println("Deleted Course id:"+courseId);
        Course tempcourse=courseRepository.findById(courseId).orElse(null);
        if(null==tempcourse){
            throw new CourseNotFoundException();
        }
        if( tempcourse.getStudents().isEmpty())
        {
                System.out.println("No enrolled Students so it can be deleted");
                System.out.println("Deleted Course:"+tempcourse);
                // Deleting all course related Enquiries before deleting course
                for (int i = 0; i < tempcourse.getEnquiries().size(); i++) {
                    Long enquiry_id=tempcourse.getEnquiries().get(i).getEnquiryId();
                    System.out.println("Deleting Enquiry id:"+enquiry_id);
                    enquiryService.deleteEnquiry(enquiry_id);
                }
                courseRepository.delete(tempcourse);
                return tempcourse;
        }
        else
        {
            System.out.println("Can not delete as Students are currently enrolled to this course");
            return null;
        }
        
    }

    @Override
    public Course editCourse(Long courseId, Course course) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public Course createCourse(Course course) {
        // TODO Auto-generated method stub
        return null;
    }
}

