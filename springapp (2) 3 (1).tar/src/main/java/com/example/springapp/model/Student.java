package com.example.springapp.model;

import java.util.ArrayList;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
public class Student  {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long studentId;

    private String studentName;
    private String studentEmail;
    private String studentMobileNumber;

    @OneToOne
    private User user;

    @OneToMany
    @JsonIgnore
	public List<Enquiry> enquiry=new ArrayList<Enquiry>();

    @ManyToMany(cascade = {CascadeType.PERSIST,CascadeType.MERGE})
    @JsonIgnore
    @JoinTable(name="student_course",joinColumns = @JoinColumn(name="studentid_course"),
                inverseJoinColumns = @JoinColumn(name="courseid_course"))
	public List<Course> courses=new ArrayList<Course>();


    public Student() {
    }

    public Student(Long studentId, String studentName, String studentEmail, String studentMobileNumber) {
        this.studentId = studentId;
        this.studentName = studentName;
        this.studentEmail = studentEmail;
        this.studentMobileNumber = studentMobileNumber;
    }

    public Student(Long studentId, String studentName, String studentEmail, String studentMobileNumber, User user) {
        this.studentId = studentId;
        this.studentName = studentName;
        this.studentEmail = studentEmail;
        this.studentMobileNumber = studentMobileNumber;
        this.user = user;
    }

    

    public Student(Long studentId, String studentName, String studentEmail, String studentMobileNumber, User user,
            List<Enquiry> enquiry) {
        this.studentId = studentId;
        this.studentName = studentName;
        this.studentEmail = studentEmail;
        this.studentMobileNumber = studentMobileNumber;
        this.user = user;
        this.enquiry = enquiry;
    }

    public Student(Long studentId, String studentName, String studentEmail, String studentMobileNumber, User user,
            List<Enquiry> enquiry, List<Course> courses) {
        this.studentId = studentId;
        this.studentName = studentName;
        this.studentEmail = studentEmail;
        this.studentMobileNumber = studentMobileNumber;
        this.user = user;
        this.enquiry = enquiry;
        this.courses = courses;
    }


    public Long getStudentId() {
        return studentId;
    }

    public void setStudentId(Long studentId) {
        this.studentId = studentId;
    }

    public String getStudentName() {
        return studentName;
    }

    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }

    public String getStudentEmail() {
        return studentEmail;
    }

    public void setStudentEmail(String studentEmail) {
        this.studentEmail = studentEmail;
    }

    public String getStudentMobileNumber() {
        return studentMobileNumber;
    }

    public void setStudentMobileNumber(String studentMobileNumber) {
        this.studentMobileNumber = studentMobileNumber;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public List<Enquiry> getEnquiry() {
        return enquiry;
    }

    public void setEnquiry(List<Enquiry> enquiry) {
        this.enquiry = enquiry;
    }

    public List<Course> getCourses() {
        return courses;
    }

    public void setCourses(List<Course> courses) {
        this.courses = courses;
    }

    public Student orElse(Object object) {
        return null;
    }
   
}