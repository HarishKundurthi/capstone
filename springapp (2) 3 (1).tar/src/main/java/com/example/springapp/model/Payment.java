package com.example.springapp.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import com.fasterxml.jackson.annotation.JsonIgnore;
@Entity
public class Payment {
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY) 
    private Long paymentId; 
    private Long studentId; 
    private Long courseId; 
    private String status;
    private  Double amountPaid; 
    private Date paymentDate; 
    private String modeOfPayment;

    @ManyToOne
    public Course course;

    public Payment() {
    }

    public Payment(Long paymentId, Long studentId, Long courseId, String status, Double amountPaid, Date paymentDate,
            String modeOfPayment) {
        this.paymentId = paymentId;
        this.studentId = studentId;
        this.courseId = courseId;
        this.status = status;
        this.amountPaid = amountPaid;
        this.paymentDate = paymentDate;
        this.modeOfPayment = modeOfPayment;
    }

    public Payment(Long paymentId, Long studentId, Long courseId, String status, Double amountPaid, Date paymentDate,
    String modeOfPayment, Course course) {
        this.paymentId = paymentId;
        this.studentId = studentId;
        this.courseId = courseId;
        this.status = status;
        this.amountPaid = amountPaid;
        this.paymentDate = paymentDate;
        this.modeOfPayment = modeOfPayment;
        this.course = course;
    }
   

    public Long getPaymentId() {
        return paymentId;
    }

    public void setPaymentId(Long paymentId) {
        this.paymentId = paymentId;
    }

    public Long getStudentId() {
        return studentId;
    }

    public void setStudentId(Long studentId) {
        this.studentId = studentId;
    }

    public Long getCourseId() {
        return courseId;
    }

    public void setCourseId(Long courseId) {
        this.courseId = courseId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Double getAmountPaid() {
        return amountPaid;
    }

    public void setAmountPaid(Double amountPaid) {
        this.amountPaid = amountPaid;
    }

    public Date getPaymentDate() {
        return paymentDate;
    }

    public void setPaymentDate(Date paymentDate) {
        this.paymentDate = paymentDate;
    }

    public String getModeOfPayment() {
        return modeOfPayment;
    }

    public void setModeOfPayment(String modeOfPayment) {
        this.modeOfPayment = modeOfPayment;
    }

    public Course getCourse() {
        return course;
    }

    public void setCourse(Course course) {
        this.course = course;
    }

   

}
