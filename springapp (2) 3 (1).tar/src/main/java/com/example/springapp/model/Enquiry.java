package com.example.springapp.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import com.fasterxml.jackson.annotation.JsonIgnore;
@Entity
public class Enquiry {

    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY) 
    private Long enquiryId; 
    private Date enquiryDate; 
    private String title; 
    private String description; 
    private String email; 
    private String enquiryType;

    @ManyToOne
    @JoinColumn(name="enquiryid_student") 
    private Student student;

    @ManyToOne
    @JoinColumn(name="enquiryid_course")
    private Course course;

    public Enquiry() {
    }
    
    public Enquiry(Long enquiryId, Date enquiryDate, String title, String description, String email,
            String enquiryType) {
        this.enquiryId = enquiryId;
        this.enquiryDate = enquiryDate;
        this.title = title;
        this.description = description;
        this.email = email;
        this.enquiryType = enquiryType;
    }
    
    public Enquiry(Long enquiryId, Date enquiryDate, String title, String description, String email, String enquiryType,
            Student student) {
        this.enquiryId = enquiryId;
        this.enquiryDate = enquiryDate;
        this.title = title;
        this.description = description;
        this.email = email;
        this.enquiryType = enquiryType;
        this.student = student;
    }

    public Enquiry(Long enquiryId, Date enquiryDate, String title, String description, String email, String enquiryType,
            Student student, Course course) {
        this.enquiryId = enquiryId;
        this.enquiryDate = enquiryDate;
        this.title = title;
        this.description = description;
        this.email = email;
        this.enquiryType = enquiryType;
        this.student = student;
        this.course = course;
    }

    public Long getEnquiryId() {
        return enquiryId;
    }

    public void setEnquiryId(Long enquiryId) {
        this.enquiryId = enquiryId;
    }

    public Date getEnquiryDate() {
        return enquiryDate;
    }

    public void setEnquiryDate(Date enquiryDate) {
        this.enquiryDate = enquiryDate;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getEnquiryType() {
        return enquiryType;
    }

    public void setEnquiryType(String enquiryType) {
        this.enquiryType = enquiryType;
    }

    public Student getStudent() {
        return student;
    }

    public void setStudent(Student student) {
        this.student = student;
    }

    public Course getCourse() {
        return course;
    }

    public void setCourse(Course course) {
        this.course = course;
    }

    
}
