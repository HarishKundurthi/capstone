package com.example.springapp.model;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;

import com.fasterxml.jackson.annotation.JsonIgnore;



@Entity
public class Course {
  
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY) 
    private Long courseId;
    private String courseName; 
    private String description; 
    private String duration; 
    private Long cost;
        
    @ManyToMany
    @JoinColumn(name="courseid_student") 
    private Set<Student> students = new HashSet<>();
        
    @OneToMany
    @JsonIgnore
    private List<Enquiry> enquiries = new ArrayList<>();

    @OneToMany
    @JsonIgnore
    public List<Payment> payment = new ArrayList<>();

    public Course() {
    }

    public Course(Long courseId, String courseName, String description, String duration, Long cost) {
        this.courseId = courseId;
        this.courseName = courseName;
        this.description = description;
        this.duration = duration;
        this.cost = cost;
    }

    public Course(Long courseId, String courseName, String description, String duration, Long cost,
            Set<Student> students) {
        this.courseId = courseId;
        this.courseName = courseName;
        this.description = description;
        this.duration = duration;
        this.cost = cost;
        this.students = students;
    }

    public Course(Long courseId, String courseName, String description, String duration, Long cost,
            Set<Student> students, List<Enquiry> enquiries) {
        this.courseId = courseId;
        this.courseName = courseName;
        this.description = description;
        this.duration = duration;
        this.cost = cost;
        this.students = students;
        this.enquiries = enquiries;
    }

    public Course(Long courseId, String courseName, String description, String duration, Long cost,
            Set<Student> students, List<Enquiry> enquiries, List<Payment> payment) {
        this.courseId = courseId;
        this.courseName = courseName;
        this.description = description;
        this.duration = duration;
        this.cost = cost;
        this.students = students;
        this.enquiries = enquiries;
        this.payment = payment;
    }

    public Long getCourseId() {
        return courseId;
    }

    public void setCourseId(Long courseId) {
        this.courseId = courseId;
    }

    public String getCourseName() {
        return courseName;
    }

    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getDuration() {
        return duration;
    }

    public void setDuration(String duration) {
        this.duration = duration;
    }

    public Long getCost() {
        return cost;
    }

    public void setCost(Long cost) {
        this.cost = cost;
    }

    public Set<Student> getStudents() {
        return students;
    }

    public void setStudents(Set<Student> students) {
        this.students = students;
    }

    public List<Enquiry> getEnquiries() {
        return enquiries;
    }

    public void setEnquiries(List<Enquiry> enquiries) {
        this.enquiries = enquiries;
    }

    public List<Payment> getPayment() {
        return payment;
    }

    public void setPayment(List<Payment> payment) {
        this.payment = payment;
    }


    
   

  

       
        
}
